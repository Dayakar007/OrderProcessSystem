﻿using OrderProcessSystem.ModelDomain;
using System;
using System.Collections.Generic;
using System.Text;
using AutoFixture;

namespace OrderProcessSystem.Helpers
{
    public static class ObjectPackagingSlip
    {
        public static PackagingSlip GetPackagingSlip()
        {
            return new Fixture().Create<PackagingSlip>();
        }

        public static RoyaltyPackagingSlip GetRoyaltyPackagingSlip()
        {
            return new Fixture().Create<RoyaltyPackagingSlip>();
        }
    }
}
