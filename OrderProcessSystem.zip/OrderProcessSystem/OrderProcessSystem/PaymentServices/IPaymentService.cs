﻿using OrderProcessSystem.ModelDomain;
using System;
using System.Collections.Generic;
using System.Text;

namespace OrderProcessSystem.PaymentServices
{
    public interface IPaymentService
    {
        bool ProcessPayment(PaymentType paymentType);
    }
}
